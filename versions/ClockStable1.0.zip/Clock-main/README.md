# Tạo đồng hồ số VTV
Tạo đồng hồ VTV - một công cụ hỗ trợ designers và editors thiết kế đồng hồ cho riêng kênh VTV phục chế của họ.
# Hiểu về đồng hồ và tên CT VTV
Đồng hồ và tên CT (tên chương trình VTV) là chỉ báo trực quan, tức là thông qua những thứ đó để người xem có thể biết được hiện tại là mấy giờ và đang trình chiếu chương trình gì
# Chỉnh sửa tên CT và đồng hồ cho riêng mình để làm gì?
Những ai phục chế các kênh không do Đài Truyền hình Việt Nam thực hiện sẽ cần ghép vào video của mình những thứ này để xem như là kênh VTV thực thụ

Ghi nhớ rằng đây chỉ là dành cho mục đích phát triển video, còn nếu dùng mà không có mục đích thì xin vui lòng bỏ qua ;)
